import React from "react";
import Navbar from "../components/Navbar";

const Home = () => {


    return (
        <div>
          <Navbar/>
            {/* Default Information Section */}
            <div className="container mt-5">
                <h1>Welcome to the Management System</h1>

            </div>
        </div>
    );
};

export default Home;
